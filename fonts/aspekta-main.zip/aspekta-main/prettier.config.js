export { default } from '@hypernym/prettier-config'

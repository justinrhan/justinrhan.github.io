# What's New

Check out the latest features and improvements.

#### [Release Notes](https://github.com/ivodolenc/aspekta/releases)
